# Docker & OpenLayer

## Installazzione Docker
Installare un editor di testo come Visual Studio Code(disponibile per Linux, Mac e Windows)
Installare Docker Desktop(Mac e Windows) mentre per gli utenti Linux bisogna installare Docker Engine)
 .[Docker Desktop](https://www.docker.com/products/docker-desktop)
 .[Docker Engine](https://docs.docker.com/engine/install/ubuntu)
Scaricare tutti i progetti
Creare il docker: docker build -t my-apache2 .
Eseguire il docker doker run -dit --name my-running-app -p 8080:80 my-apache2
per maggiori informazioni(https://hub.docker.com/_/httpd)
Installare [Postgress SQL](https://hub.docker.com/_/postgres)
Installare[GeoServer](https://hub.docker.com/r/kartoza/geoserver)


 

### Conclusione
Adesso siete pronti per sbizzarrirvi 

ciao
